// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.devtools.idealized.log.model;

import org.openqa.selenium.internal.Require;

public class LogEntry {

  private final String kind;
  private final org.openqa.selenium.logging.LogEntry entry;

  public LogEntry(String kind, org.openqa.selenium.logging.LogEntry entry) {
    this.kind = Require.nonNull("Kind", kind);
    this.entry = Require.nonNull("Entry", entry);
  }

  public String getKind() {
    return kind;
  }

  public org.openqa.selenium.logging.LogEntry getEntry() {
    return entry;
  }
}
