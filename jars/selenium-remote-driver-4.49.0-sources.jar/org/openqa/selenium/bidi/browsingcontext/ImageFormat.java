// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.
package org.openqa.selenium.bidi.browsingcontext;

import java.util.Map;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.internal.Require;

@Beta
public class ImageFormat {
  private final String type;
  private final @Nullable Double quality;

  public ImageFormat(String type, @Nullable Double quality) {
    this.type = Require.nonNull("Image type", type);
    this.quality =
        quality == null ? null : Require.inRangeInclusive("Image quality", quality, 0.0, 1.0);
  }

  public Map<String, @Nullable Object> toMap() {
    return quality == null ? Map.of("type", type) : Map.of("type", type, "quality", quality);
  }

  @Override
  public String toString() {
    return String.format("%s{%s}", getClass().getSimpleName(), toMap());
  }
}
